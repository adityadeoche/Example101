•	Project overview (1–2 lines).
	•	Setup: MySQL at localhost:3306, tourist_guide schema, util/Db.java URL/user/password, driver jar on classpath. 
	•	How to run: Right‑click app/MainMenu > Run As > Java Application. 
	•	Demo steps: 2, 4, 6; 8; 7; 9 (limit 5); 10. 
	•	Reset: run seed.sql in MySQL Workbench; optional TRUNCATE block. 
	•	Screenshots: mention menu.png and booking_report.png if adding
	
	
	•	Start sections with lines like:
	•	TouristGuide
	•	Setup
	•	How to run
	•	Demo steps
	•	Reset
	•	Screenshots 