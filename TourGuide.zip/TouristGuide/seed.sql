-- TouristGuide demo seed
-- Usage in Workbench: open this file and Execute (lightning bolt)
-- Usage in terminal:  mysql -u root -p < seed.sql

CREATE DATABASE IF NOT EXISTS tourist_guide;
USE tourist_guide;

-- Optional: clean minimal tables before seeding (beware: deletes demo data)
-- SET FOREIGN_KEY_CHECKS=0;
-- TRUNCATE TABLE visits;
-- TRUNCATE TABLE bookings;
-- TRUNCATE TABLE attractions;
-- TRUNCATE TABLE hotels;
-- TRUNCATE TABLE tourists;
-- SET FOREIGN_KEY_CHECKS=1;

-- Ensure required tables exist (adjust if your schema already created them)
CREATE TABLE IF NOT EXISTS tourists (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  phone VARCHAR(20),
  email VARCHAR(120)
);

CREATE TABLE IF NOT EXISTS hotels (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  location VARCHAR(120),
  phone VARCHAR(20)
);

CREATE TABLE IF NOT EXISTS attractions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(120) NOT NULL,
  district VARCHAR(80),
  type VARCHAR(60),
  description TEXT
);

CREATE TABLE IF NOT EXISTS bookings (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tourist_id INT NOT NULL,
  hotel_id INT NOT NULL,
  check_in DATE NOT NULL,
  check_out DATE NOT NULL,
  FOREIGN KEY (tourist_id) REFERENCES tourists(id) ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (hotel_id)  REFERENCES hotels(id)   ON DELETE CASCADE ON UPDATE CASCADE
);

CREATE TABLE IF NOT EXISTS visits (
  id INT AUTO_INCREMENT PRIMARY KEY,
  tourist_id INT NOT NULL,
  attraction_id INT NOT NULL,
  visited_on DATE NOT NULL,
  rating INT NULL,
  FOREIGN KEY (tourist_id)   REFERENCES tourists(id)   ON DELETE CASCADE ON UPDATE CASCADE,
  FOREIGN KEY (attraction_id) REFERENCES attractions(id) ON DELETE CASCADE ON UPDATE CASCADE
);

-- Seed tourists
INSERT INTO tourists (name, phone, email) VALUES
('Anuj','9876543210','anuj@example.com'),
('Riya','9123456789','riya@example.com'),
('Test Tourist','9000000000','test@example.com');

-- Seed hotels
INSERT INTO hotels (name, location, phone) VALUES
('Fort View Inn','Raigad','0201234567'),
('Sahyadri Stay','Pune','0207654321');

-- Seed attractions
INSERT INTO attractions (name, district, type, description) VALUES
('Raigad Fort','Raigad','Fort','Historic Maratha fort.'),
('Sinhagad Fort','Pune','Fort','Popular trekking destination.');

-- Seed bookings (align IDs with inserted rows)
-- Tourists: (1 Anuj), (2 Riya), (3 Test Tourist)
-- Hotels:   (1 Fort View Inn), (2 Sahyadri Stay)
INSERT INTO bookings (tourist_id, hotel_id, check_in, check_out) VALUES
(1,1,'2025-10-05','2025-10-07'),
(2,2,'2025-10-06','2025-10-08');

-- Seed visits (align IDs with inserted rows)
-- Attractions: (1 Raigad Fort), (2 Sinhagad Fort)
INSERT INTO visits (tourist_id, attraction_id, visited_on, rating) VALUES
(1,2,'2025-10-02',4),
(3,1,'2025-10-03',NULL),
(1,2,'2025-10-06',5);

-- Done. Lists and reports will now show predictable data.
