package util;

import java.time.LocalDate;

public final class Validators {
    private Validators() {}

    public static boolean isNonEmpty(String s) {
        return s != null && !s.trim().isEmpty();
    }

    public static boolean isPhone(String s) {
        return s != null && s.matches("\\d{7,15}");
    }

    public static boolean isEmail(String s) {
        return s != null && s.contains("@") && s.contains(".");
    }

    public static LocalDate parseIsoDateOrNull(String s) {
        if (s == null) return null;
        try { return LocalDate.parse(s.trim()); }
        catch (Exception e) { return null; }
    }
}
