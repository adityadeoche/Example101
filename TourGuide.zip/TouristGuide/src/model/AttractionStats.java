package model;
public record AttractionStats(String attraction, long totalVisits) {}
