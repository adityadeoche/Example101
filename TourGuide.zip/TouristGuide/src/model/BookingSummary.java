package model;
import java.time.LocalDate;
public record BookingSummary(String tourist, String hotel, LocalDate checkIn, LocalDate checkOut) {}
