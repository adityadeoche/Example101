package model;
import java.time.LocalDate;
public record VisitSummary(String tourist, String attraction, LocalDate visitedOn, Integer rating) {}
