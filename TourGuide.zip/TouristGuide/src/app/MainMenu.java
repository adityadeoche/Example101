package app;

import dao.TouristDao;
import dao.HotelDao;
import dao.AttractionDao;
import dao.ReportDao;
import dao.BookingDao;
import util.Validators;
import java.time.LocalDate;
import java.util.Scanner;

public class MainMenu {
    public static void main(String[] args) throws Exception {
        var tourists = new TouristDao();
        var hotels   = new HotelDao();
        var atts     = new AttractionDao();
        var reports  = new ReportDao();
        var bookings = new BookingDao();
        var sc = new Scanner(System.in);

        while (true) {
            System.out.println("\n=== TouristGuide Menu ===");
            System.out.println("1) Add tourist");
            System.out.println("2) List tourists");
            System.out.println("3) Add hotel");
            System.out.println("4) List hotels");
            System.out.println("5) Add attraction");
            System.out.println("6) List attractions");
            System.out.println("7) Show booking report");
            System.out.println("8) Add booking");
            System.out.println("9) Recent visits (limit)");
            System.out.println("10) Attraction popularity");
            System.out.println("0) Exit");
            System.out.print("Choice: ");

            int ch;
            try {
                String choiceLine = sc.nextLine().trim();
                ch = Integer.parseInt(choiceLine);
            } catch (NumberFormatException nfe) {
                System.out.println("Enter a number.");
                continue;
            }

            try {
                switch (ch) {
                    case 1 -> {
                        System.out.print("Name: ");   String n = sc.nextLine().trim();
                        System.out.print("Phone: ");  String p = sc.nextLine().trim();
                        System.out.print("Email: ");  String e = sc.nextLine().trim();

                        if (!Validators.isNonEmpty(n)) { System.out.println("Name required."); break; }
                        if (!Validators.isPhone(p))     { System.out.println("Phone must be 7-15 digits."); break; }
                        if (!Validators.isEmail(e))     { System.out.println("Email looks invalid."); break; }

                        int id = tourists.add(n, p, e);
                        System.out.println("Inserted tourist id: " + id);
                    }
                    case 2 -> tourists.list().forEach(System.out::println);
                    case 3 -> {
                        System.out.print("Hotel name: "); String n = sc.nextLine().trim();
                        System.out.print("Location: ");   String loc = sc.nextLine().trim();
                        System.out.print("Phone: ");      String ph = sc.nextLine().trim();

                        if (!Validators.isNonEmpty(n)) { System.out.println("Hotel name required."); break; }

                        int id = hotels.add(n, loc, ph);
                        System.out.println("Inserted hotel id: " + id);
                    }
                    case 4 -> hotels.list().forEach(System.out::println);
                    case 5 -> {
                        System.out.print("Attraction name: "); String n = sc.nextLine().trim();
                        System.out.print("District: ");        String d = sc.nextLine().trim();
                        System.out.print("Type: ");            String t = sc.nextLine().trim();

                        if (!Validators.isNonEmpty(n)) { System.out.println("Attraction name required."); break; }

                        int id = atts.add(n, d, t);
                        System.out.println("Inserted attraction id: " + id);
                    }
                    case 6 -> atts.list().forEach(System.out::println);
                    case 7 -> {
                    	for (model.BookingSummary b : reports.bookingSummary()) {
                    	    System.out.println(b.tourist()+" | "+b.hotel()+" | "+b.checkIn()+" -> "+b.checkOut());
                    	}

                    }
                    case 8 -> {
                        try {
                            System.out.print("Tourist ID (or 0 to cancel): ");
                            String tStr = sc.nextLine().trim();
                            if (tStr.equals("0")) { System.out.println("Cancelled."); break; }
                            int tId;
                            try { tId = Integer.parseInt(tStr); }
                            catch (NumberFormatException nfe) { System.out.println("Enter a number."); break; }

                            System.out.print("Hotel ID (or 0 to cancel): ");
                            String hStr = sc.nextLine().trim();
                            if (hStr.equals("0")) { System.out.println("Cancelled."); break; }
                            int hId;
                            try { hId = Integer.parseInt(hStr); }
                            catch (NumberFormatException nfe) { System.out.println("Enter a number."); break; }

                            System.out.print("Check-in (YYYY-MM-DD, e.g., 2025-10-20): ");
                            String inStr = sc.nextLine().trim();
                            System.out.print("Check-out (YYYY-MM-DD, e.g., 2025-10-22): ");
                            String outStr = sc.nextLine().trim();

                            LocalDate inD  = Validators.parseIsoDateOrNull(inStr);
                            LocalDate outD = Validators.parseIsoDateOrNull(outStr);
                            if (inD == null || outD == null) {
                                System.out.println("Invalid date (use YYYY-MM-DD, e.g., 2025-10-20).");
                                break;
                            }

                            if (outD.isBefore(inD)) { System.out.println("check_out must be on or after check_in."); break; }
                            if (!bookings.touristExists(tId)) { System.out.println("Tourist id not found."); break; }
                            if (!bookings.hotelExists(hId))   { System.out.println("Hotel id not found."); break; }

                            int id = bookings.add(tId, hId, inD, outD);
                            System.out.println("Inserted booking id: " + id);
                        } catch (Exception e) {
                            System.out.println("Failed to add booking: " + e.getMessage());
                        }
                    }
                    case 9 -> {
                        System.out.print("Limit: ");
                        String limStr = sc.nextLine().trim();
                        int lim;
                        try { lim = Integer.parseInt(limStr); }
                        catch (NumberFormatException nfe) { System.out.println("Enter a number."); break; }

                        reports.visitsByRecentDate(lim).forEach(v -> {
                            String ratingText = (v.rating() == null) ? "-" : v.rating().toString();
                            System.out.println(v.tourist()+" | "+v.attraction()+" | "+v.visitedOn()+" | "+ratingText);
                        });
                    }

                    case 10 -> reports.attractionPopularity().forEach(s ->
                        System.out.println(s.attraction()+" | "+s.totalVisits()));
                    case 0 -> { System.out.println("Bye"); sc.close(); return;}
                    
                    default -> System.out.println("Invalid choice");
                }
            } catch (Exception ex) {
                System.out.println("Operation failed: " + ex.getMessage());
            }
        }
    }
}
