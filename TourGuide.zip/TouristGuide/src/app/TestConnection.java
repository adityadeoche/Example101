package app;

import util.Db;
import java.sql.Connection;
import java.sql.DatabaseMetaData;

public class TestConnection {
    public static void main(String[] args) {
        try (Connection c = Db.get()) {
            DatabaseMetaData md = c.getMetaData();
            System.out.println("Connected to: " + md.getURL());
            System.out.println("Driver: " + md.getDriverName() + " " + md.getDriverVersion());
            System.out.println("User: " + md.getUserName());
        } catch (Exception e) {
            System.out.println("Connection failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
}
