package app;

import dao.ReportDao;
import model.BookingSummary;   // add this import

public class ReportRunner {
    public static void main(String[] args) throws Exception {
        for (BookingSummary row : new ReportDao().bookingSummary()) {
            System.out.println(row.tourist() + " | " + row.hotel() + " | " +
                               row.checkIn() + " -> " + row.checkOut());
        }
    }
}
