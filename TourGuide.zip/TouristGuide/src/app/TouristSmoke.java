package app;

import dao.TouristDao;

public class TouristSmoke {
    public static void main(String[] args) throws Exception {
        var dao = new TouristDao();
        int id = dao.add("Test Tourist", "9000000000", "test@tourist.com");
        System.out.println("Inserted tourist id: " + id);
        dao.list().forEach(System.out::println);
    }
}
