package app;

import dao.BookingDao;
import java.time.LocalDate;

public class BookingSmoke {
    public static void main(String[] args) throws Exception {
        var dao = new BookingDao();

        // TODO: set existing IDs from your DB before running
        int touristId = 1;
        int hotelId   = 1;

        var in  = LocalDate.parse("2025-10-15");
        var out = LocalDate.parse("2025-10-17");

        int id = dao.add(touristId, hotelId, in, out);
        System.out.println("Inserted booking id: " + id);

        dao.list().forEach(System.out::println);
    }
}
