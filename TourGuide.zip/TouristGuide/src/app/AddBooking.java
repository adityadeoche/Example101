package app;

import util.Db;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;

public class AddBooking {
    public static void main(String[] args) throws Exception {
        // TODO: replace these with real, existing IDs from your DB
        int touristId = 1;
        int hotelId   = 1;

        // Validate IDs are set
        if (touristId <= 0 || hotelId <= 0) {
            System.out.println("Set valid touristId and hotelId before running.");
            return;
        }

        String sql = "INSERT INTO bookings(tourist_id, hotel_id, check_in, check_out) VALUES(?,?,?,?)";

        try (Connection c = Db.get();
             PreparedStatement ps = c.prepareStatement(sql)) {

            ps.setInt(1, touristId);
            ps.setInt(2, hotelId);
            ps.setDate(3, Date.valueOf("2025-10-10")); // YYYY-MM-DD
            ps.setDate(4, Date.valueOf("2025-10-12")); // check_out must be >= check_in

            int rows = ps.executeUpdate();
            System.out.println("Booking inserted, rows affected: " + rows);
        }
    }
}
