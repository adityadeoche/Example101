package dao;

import util.Db;
import java.sql.*;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

public class BookingDao {

    // Insert a booking and return generated id
    public int add(int touristId, int hotelId, LocalDate checkIn, LocalDate checkOut) throws Exception {
        if (checkOut.isBefore(checkIn)) {
            throw new IllegalArgumentException("check_out must be on or after check_in");
        }
        String sql = "INSERT INTO bookings(tourist_id, hotel_id, check_in, check_out) VALUES(?,?,?,?)";
        try (Connection c = Db.get();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, touristId);
            ps.setInt(2, hotelId);
            ps.setDate(3, Date.valueOf(checkIn));
            ps.setDate(4, Date.valueOf(checkOut));
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

    // Optional: list joined booking lines for debugging
    public List<String> list() throws Exception {
        String sql = """
            SELECT b.id, t.name AS tourist, h.name AS hotel, b.check_in, b.check_out
            FROM bookings b
            JOIN tourists t ON b.tourist_id = t.id
            JOIN hotels   h ON b.hotel_id   = h.id
            ORDER BY b.check_in
        """;
        List<String> out = new ArrayList<>();
        try (Connection c = Db.get();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                out.add(
                    rs.getInt("id") + " | " +
                    rs.getString("tourist") + " | " +
                    rs.getString("hotel") + " | " +
                    rs.getDate("check_in") + " -> " +
                    rs.getDate("check_out")
                );
            }
        }
        return out;
    }

    // Optional: existence checks to pre‑validate foreign keys
    public boolean touristExists(int id) throws Exception {
        try (Connection c = Db.get();
             PreparedStatement ps = c.prepareStatement("SELECT 1 FROM tourists WHERE id=?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        }
    }
    public boolean hotelExists(int id) throws Exception {
        try (Connection c = Db.get();
             PreparedStatement ps = c.prepareStatement("SELECT 1 FROM hotels WHERE id=?")) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) { return rs.next(); }
        }
    }
}
