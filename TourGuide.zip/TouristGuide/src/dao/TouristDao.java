package dao;

import util.Db;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TouristDao {

    // Insert a tourist and return the generated primary key id
    public int add(String name, String phone, String email) throws Exception {
        String sql = "INSERT INTO tourists(name, phone, email) VALUES(?,?,?)";
        try (Connection c = Db.get();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, name);
            ps.setString(2, phone);
            ps.setString(3, email);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

    // Return simple lines: "id | name | phone"
    public List<String> list() throws Exception {
        String sql = "SELECT id, name, phone FROM tourists ORDER BY id";
        List<String> out = new ArrayList<>();
        try (Connection c = Db.get();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                out.add(rs.getInt(1) + " | " + rs.getString(2) + " | " + rs.getString(3));
            }
        }
        return out;
    }
}
