package dao;

import util.Db;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import model.BookingSummary;
import model.VisitSummary;
import model.AttractionStats;

/**
 * Read-only reporting queries for the TouristGuide app.
 */
public class ReportDao {

    /**
     * Returns booking summaries by joining bookings, tourists, and hotels.
     * Format: "<tourist> | <hotel> | <check_in> -> <check_out>"
     */
	public List<BookingSummary> bookingSummary() throws Exception {
	    String sql = """
	        SELECT t.name AS tourist, h.name AS hotel, b.check_in, b.check_out
	        FROM bookings b
	        JOIN tourists t ON b.tourist_id = t.id
	        JOIN hotels   h ON b.hotel_id   = h.id
	        ORDER BY b.check_in
	    """;
	    List<BookingSummary> rows = new ArrayList<>();
	    try (Connection c = Db.get();
	         PreparedStatement ps = c.prepareStatement(sql);
	         ResultSet rs = ps.executeQuery()) {
	        while (rs.next()) {
	            rows.add(new BookingSummary(
	                rs.getString("tourist"),
	                rs.getString("hotel"),
	                rs.getDate("check_in").toLocalDate(),
	                rs.getDate("check_out").toLocalDate()
	            ));
	        }
	    }
	    return rows;
	}


    /**
     * Recent visits with tourist and attraction names, newest first.
     * Requires table 'visits(tourist_id, attraction_id, visited_on, rating)'.
     */
    public List<VisitSummary> visitsByRecentDate(int limit) throws Exception {
        String sql = """
            SELECT t.name AS tourist, a.name AS attraction, v.visited_on, v.rating
            FROM visits v
            JOIN tourists t ON v.tourist_id = t.id
            JOIN attractions a ON v.attraction_id = a.id
            ORDER BY v.visited_on DESC
            LIMIT ?
        """;
        List<VisitSummary> out = new ArrayList<>();
        try (Connection c = Db.get(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, limit);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    out.add(new VisitSummary(
                        rs.getString("tourist"),
                        rs.getString("attraction"),
                        rs.getDate("visited_on").toLocalDate(),
                        (Integer) rs.getObject("rating")
                    ));
                }
            }
        }
        return out;
    }

    /**
     * Attraction popularity ranked by total visits descending.
     * Requires table 'visits' with FK to 'attractions'.
     */
    public List<AttractionStats> attractionPopularity() throws Exception {
        String sql = """
            SELECT a.name AS attraction, COUNT(*) AS total
            FROM visits v
            JOIN attractions a ON v.attraction_id = a.id
            GROUP BY a.name
            ORDER BY total DESC, a.name
        """;
        List<AttractionStats> out = new ArrayList<>();
        try (Connection c = Db.get(); PreparedStatement ps = c.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                out.add(new AttractionStats(
                    rs.getString("attraction"),
                    rs.getLong("total")
                ));
            }
        }
        return out;
    }
}
