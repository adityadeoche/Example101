package dao;

import util.Db;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class HotelDao {

    public int add(String name, String location, String phone) throws Exception {
        String sql = "INSERT INTO hotels(name, location, phone) VALUES(?,?,?)";
        try (Connection c = Db.get();
             PreparedStatement ps = c.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, name);
            ps.setString(2, location);
            ps.setString(3, phone);
            ps.executeUpdate();
            try (ResultSet rs = ps.getGeneratedKeys()) {
                return rs.next() ? rs.getInt(1) : 0;
            }
        }
    }

    public List<String> list() throws Exception {
        String sql = "SELECT id, name, location FROM hotels ORDER BY id";
        List<String> out = new ArrayList<>();
        try (Connection c = Db.get();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                out.add(rs.getInt(1) + " | " + rs.getString(2) + " | " + rs.getString(3));
            }
        }
        return out;
    }
}
